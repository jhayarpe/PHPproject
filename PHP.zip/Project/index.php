<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style/index.css">
    <title>Log-in</title>
</head>
<body style="background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url('bg.jpg');">
<form>

<div class="text"><p>"Efficiency, Precision, and Care: Our Hospital Management System brings seamless organization to healthcare operations, ensuring every patient receives the attention they deserve while streamlining administrative tasks for a healthier, happier tomorrow."</p></div>
<div class="d-flex justify-content-center align-items-center" style="height: 100vh; padding-left: 60%;">
    <div class="p-5 m-3 px-5 border" style="border-radius: 5px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3); background-color: rgba(255, 255, 255, 0.3);" >  
        <div class="mb-3" style="text-align: center"><h2>LOG IN</h2></div>
        <div class="form-floating mb-3">
            <input type="username" class="form-control" id="username" placeholder="Username">
            <label for="floatingInput">Email address</label>
        </div>
        <div class="form-floating mb-3">
            <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
            <label for="floatingPassword">Password</label>
        </div>
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Show Password</label>
        </div>
        <button type="submit" class="btn btn-primary" style="width: 40vh">Submit</button>
        <div class="mb-3">
            <label class="mt-5">Don't have an account?  <a href="register.php" style="color: blue; text-decoration: underline;">Sign-up</a></label>
        </div>
    </div>
</div>


</form>
</body>
</html>