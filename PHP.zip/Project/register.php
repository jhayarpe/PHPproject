<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style/registration.css">
    <title>Register</title>
</head>
<body style="background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url('bg.jpg');">
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4" >
                <div class="card">
                    <div class="card-header" >
                        <h3 class="text-center mt-3">Registration Form</h3>
                    </div>
                    <div class="card-body">
                        <form action = "includes/registration.inc.php" method="POST">
                            <div class="row">
                                <div class="col">
                                    <input type="text" class="form-control" name="firstname" placeholder="First name" aria-label="First name">
                                </div>
                                <div class="col mb-3">
                                    <input type="text" class="form-control" name="lastname" placeholder="Last name" aria-label="Last name">
                                </div>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
                            </div>
                            <div class="mb-3">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                            </div>
                            <div class="mb-3">
                                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Enter confirmpassword" required>
                            </div>
                            <div class="mb-3">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter email address" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Register</button>
                            </div>
                            <div class="mt-3"><p>Already have an accunt? <a href="index.php">Log-in</a></p></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>