<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmPassword'];
    $email = $_POST['email'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];

    try {
        require_once "dbc.inc.php";

        $query = "INSERT INTO useraccount(userName,userPassword,userConfirmPass,userEmail,firstName,lastName) values(:userName,:userPassword,:userConfirmPass,:userEmail,:firstname,:lastname);";
    
        $stmt = $pdo->prepare($query);

        $stmt->bindParam(":userName", $username);
        $stmt->bindParam(":userPassword", $password);
        $stmt->bindParam(":userConfirmPass", $confirmpassword);
        $stmt->bindParam(":userEmail", $email);
        $stmt->bindParam(":firstname", $firstname);
        $stmt->bindParam(":lastname", $lastname);

        $stmt->execute();

        $pdo = null;
        $stmt = null;

        header("Location:.. /register.php");
        die();
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
}else{
    header("Location:.. /index.php");
}